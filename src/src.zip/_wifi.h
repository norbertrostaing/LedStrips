#include <ETH.h>
#include "_config.h"

void setupWifi();