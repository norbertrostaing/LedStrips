#include <ArduinoOSCWiFi.h>

void setupOSC();
extern int oscPort;
